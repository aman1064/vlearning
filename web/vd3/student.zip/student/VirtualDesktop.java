package virtdesk;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;

public class VirtualDesktop extends Frame implements ActionListener
{
	CustomButton cb1, cb2, cb3, cb4, ok_btn, reset_btn;
	CustomLabel cls, chat;
	CardLayout cd = new CardLayout();

	Panel main_panel, first_screen,login_screen, Options_screen, menu_screen;
	TextField login_name, password;

	Frame frame;
	String login_name_txt = "";
	ScreenConsumer consumer;
	PlayerTest audioPlayer;
	String ip = "";

	public VirtualDesktop()
	{
		super( "Virtual Desktop - Enabling TruE-Learning" );
		setLayout( null );	setBackground( Color.white );
		frame = this;
//-------------------------
		CustomLabel cl = new CustomLabel( Toolkit.getDefaultToolkit().createImage( "imgs/logo.jpg" ), 0, 20 );
		cl.setBounds( 40, 2, 310, 65 );		cl.setBackground( Color.white );
		add( cl );

		CustomLabel cl2 = new CustomLabel( Toolkit.getDefaultToolkit().createImage( "imgs/foot.gif" ), 0, 0 );
		cl2.setBounds( 0, 382, 400, 17 );	cl2.setBackground( Color.white );
		add( cl2 );
//-------------------------
		Label margin1 = new Label( );	margin1.setBackground( new Color( 200, 51, 0 ) );
		margin1.setBounds( 125, 70, 2, 312 );	add( margin1 );

		Label margin2 = new Label( );	margin2.setBackground( new Color( 200, 51, 0 ) );
		margin2.setBounds( 0, 68, 400, 2);	add( margin2 );
//-------------------------
		cb1 =  new CustomButton( Toolkit.getDefaultToolkit().createImage( "imgs/login.gif" ) );
		cb1.setBounds( 10, 75, 110, 18 );	cb1.addActionListener( this );
		add( cb1 );

		cb2 =  new CustomButton( Toolkit.getDefaultToolkit().createImage( "imgs/help.gif" ) );
		cb2.setBounds( 10, 105, 110, 18 );	cb2.addActionListener( this );
		add( cb2 );

		cb3 =  new CustomButton( Toolkit.getDefaultToolkit().createImage( "imgs/exit.gif" ) );
		cb3.setBounds( 10, 135, 110, 18 );	cb3.addActionListener( this );
		add( cb3 );

		cb4 =  new CustomButton( Toolkit.getDefaultToolkit().createImage( "imgs/logout.gif" ) );
		cb4.setBounds( 10, 165, 110, 18 );	cb4.addActionListener( this );		cb4.setEnabled( false );
		add( cb4 );

		CustomLabel cc = new CustomLabel( Toolkit.getDefaultToolkit().createImage( "imgs/consulting2.jpg" ), 0, 0 );
		cc.setBounds( 10, 265, 110, 105 );		cc.setBackground( Color.yellow );
		add( cc );

//---------------------------------------
		main_panel = new Panel();	main_panel.setLayout( cd );	main_panel.setBounds( 125, 70, 273, 312 );
//**********************
		first_screen = new Panel();	first_screen.setLayout( null );

		CustomLabel first = new CustomLabel( Toolkit.getDefaultToolkit().createImage( "imgs/main.jpg" ), 0, 0 );
		first.setBounds( 10, 35, 250, 210 );	first.setBackground( Color.green );
		first_screen.add( first );

		CustomLabel ee = new CustomLabel( Toolkit.getDefaultToolkit().createImage( "imgs/tom.gif" ), 0, 0 );
		ee.setBounds( 5, 255, 260, 17 );	ee.setBackground( Color.green );
		first_screen.add( ee );

		CustomLabel ff = new CustomLabel( Toolkit.getDefaultToolkit().createImage( "imgs/prep.gif" ), 0, 0 );
		ff.setBounds( 60, 285, 140, 17 );	ff.setBackground( Color.green );
		first_screen.add( ff );
//**********************
		login_screen = new Panel();	login_screen.setLayout( null );

		Label l1 =  new Label(  "User Name : " );		l1.setBounds( 10, 30, 100, 20 );	l1.setForeground( Color.red );	l1.setFont( new Font( "Serif", Font.BOLD, 15 ) );
		Label l2 =  new Label(  "Password    : " );	l2.setBounds( 10, 70, 100, 20 );	l2.setForeground( Color.red );	l2.setFont( new Font( "Serif", Font.BOLD, 15 ) );

		login_name =  new TextField();	login_name.setBounds( 110, 30, 150, 20 );	login_name.setForeground( Color.blue );
		password =  new TextField();		password.setBounds( 110, 70, 150, 20 );	password.setForeground( Color.blue );		password.setEchoChar( '*' );

		ok_btn = new CustomButton( Toolkit.getDefaultToolkit().createImage( "imgs/ok.gif" ) );
		ok_btn.setBounds( 70, 100, 60, 18 );		ok_btn.addActionListener( this );
		reset_btn =  new CustomButton( Toolkit.getDefaultToolkit().createImage( "imgs/reset.gif" ) );
		reset_btn.setBounds( 150, 100, 60, 18 );	reset_btn.addActionListener( this );

		login_screen.add( l1 );		login_screen.add( l2 );
		login_screen.add( login_name );	login_screen.add( password );
		login_screen.add( ok_btn );		login_screen.add( reset_btn );
//**********************
		menu_screen = new Panel();	menu_screen.setLayout( null );

		CustomLabel log = new CustomLabel( Toolkit.getDefaultToolkit().createImage( "imgs/connect.gif" ), 0, 0 );
		log.setBounds(5, 20, 265, 24 );	log.setBackground( Color.green );
		menu_screen.add( log );

		cls = new CustomLabel( Toolkit.getDefaultToolkit().createImage( "imgs/class.gif" ), 0, 0 );
		cls.setBounds(65, 100, 112, 16 );	cls.setBackground( Color.green );
		menu_screen.add( cls );
		cls.addMouseListener(  new MouseAdapter()
		{
			public void mouseClicked( MouseEvent me )
			{
System.out.println( login_name_txt );
			      try{
System.out.println( "1.." );
				URL url =  new URL( "http://localhost:8080/vd3/student_class_starter.jsp?id=" + login_name_txt.trim() );
				URLConnection urlcon = url.openConnection();
				InputStream is = urlcon.getInputStream();
System.out.println( "3" );
				int ch;
				String str = "";
				while( (ch = is.read() ) != -1 )
					str += (char) ch;
System.out.println( "4" );
				is.close();
				is = null;
				System.gc();
System.out.println( "5" );
				if( str.trim().startsWith( "success" ) )
				{
					ip = str.trim().substring( str.trim().indexOf( ";" ) + 1 ).trim();

					//audioPlayer = new PlayerTest();
					Process proc = Runtime.getRuntime().exec( "java virtdesk.ScreenConsumer " + ip.trim() );
System.out.println( "ScreenConsumer started " );
					//Process proc1 = Runtime.getRuntime().exec( "java virtdesk.PlayerTest " + ip.trim() );
					new PlayerTest( ip.trim() );
System.out.println( "PlayerTest started " );
					//proc.waitFor();
				}
				else if( str.trim().equals( "failure" ) )
					new MessageDialog( frame, "Request failed.   Requested class has not started yet.  Please try later!!" );
System.out.println( "6" );
			     }catch( Exception eee ){	new MessageDialog( frame, "Login failed.   Could not connect to server.  Please try later!!" );	}
			}
		} 	);

		chat = new CustomLabel( Toolkit.getDefaultToolkit().createImage( "imgs/chat.gif" ), 0, 0 );
		chat.setBounds(65, 180, 112, 16 );	chat.setBackground( Color.green );
		menu_screen.add( chat );
		chat.addMouseListener(  new MouseAdapter()
		{
			public void mouseClicked( MouseEvent me )
			{
				new Client( login_name_txt.trim() );
			}
		} 	);
//------------------------
		main_panel.add( first_screen, "first_panel" );
		main_panel.add( login_screen, "login_panel" );
		main_panel.add( menu_screen, "menu_panel" );

		add( main_panel );

		addWindowListener( new WindowAdapter()
		{
			public void windowClosing( WindowEvent we )
			{	System.exit( 0 );	}
		});
	}

	public void actionPerformed( ActionEvent ae )
	{
		if( ae.getSource() == cb1 )	//show login panel
		{
			cd.show( main_panel, "login_panel" );
		}
		else if( ae.getSource() == cb2 ) //handle help menu
		{
System.out.println( "2" );
		}
		else if( ae.getSource() == cb3 ) //handle program termination
		{
			System.exit( 0 );
		}
		else if( ae.getSource() == cb4 ) //handle logout
		{
			login_name_txt = "";
			cb1.setEnabled( true );
			cb4.setEnabled( false );
			cd.show( main_panel, "first_panel" );
			try{	Thread.sleep( 2000 );	}catch( Exception ex ){}
			new MessageDialog( frame, "Logout operation completed successfully" );
		}
		else if( ae.getSource() == ok_btn )	//handle login validation
		{
System.out.println( "1" );
			try{
				String name = login_name.getText();
				String pass = password.getText();

				if( name == null || pass == null )
				{
					new MessageDialog( frame, "Cannot proceed.  Inputs are not complete" );
					return;
				}
				if( name.trim().equals( "" ) || pass.trim().equals( "" ) )
				{
					new MessageDialog( frame, "Cannot proceed.  Inputs are not complete" );
					return;
				}

			      try{
System.out.println( "2.."  + name + "..." + pass );
				URL url =  new URL( "http://localhost:8080/vd3/login_handler.jsp?id=" + name.trim() + "&pwd=" + pass.trim() + "&type=Student" );
				URLConnection urlcon = url.openConnection();
				InputStream is = urlcon.getInputStream();
System.out.println( "3" );
				int ch;
				String str = "";
				while( (ch = is.read() ) != -1 )
					str += (char) ch;
System.out.println( "4" );
				is.close();
				is = null;
				System.gc();
System.out.println( "5" );
				if( str.trim().equals( "success" ) )
				{
					cb1.setEnabled( false );
					cb4.setEnabled( true );

					login_name_txt = name;
					cd.show( main_panel, "menu_panel" );
					new MessageDialog( frame, "Login Successful." );
				}
				else if( str.trim().equals( "failure" ) )
					new MessageDialog( frame, "Login failed.   Specified user name does not exist!!" );
				else if( str.trim().equals( "failure2" ) )
					new MessageDialog( frame, "Login failed.   The password does not match!!" );
System.out.println( "6" );
			     }catch( Exception eee ){	new MessageDialog( frame, "Login failed.   Could not connect to server.  Please try later!!" );	}
			}catch( Exception ee ){	System.out.println( ee );	}
		}
		else if( ae.getSource() == reset_btn )
		{
			login_name.setText( "" );
			password.setText( "" );
		}
	}
	public static void main( String _[] )
	{
		VirtualDesktop vault = new VirtualDesktop();
		vault.setSize( 400, 400 );
		vault.setVisible( true );
		vault.setResizable( false );
	}
}