package virtdesk;

import java.awt.*;
import java.awt.event.*;

public class CustomButton extends Button
{
	Image img;
	CustomButton( Image img )
	{
		this.img = img;
	}
	public void setImage( Image img )
	{	
		this.img = img;
		repaint();
	}
	public void paint( Graphics g )
	{
		g.drawImage( img, 0,0, this );
	}
}


