package virtdesk;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.sound.sampled.*;
import java.net.*;

public class PlayerTest
{
  	AudioFormat audioFormat;
  	AudioInputStream audioInputStream;
  	TargetDataLine targetDataLine;
  	SourceDataLine sourceDataLine;

	String ip = "";
	Socket socket;
	InputStream is = null;

  	public static void main( String args[])
	{
System.out.println( "Inside main of PlayerTest : " + args[ 0 ] );
		    new PlayerTest( args[ 0] );
	}

  	public PlayerTest( String ip_addr )
	{
System.out.println( "inside PlayerTest() ..." + ip_addr );
		ip = ip_addr;
		try{	playAudio();	}catch( Exception e ){	System.out.println( e );	}
	}

	public void stopAudioReception()
	{
		targetDataLine.stop();
		targetDataLine.close();
	}
  	private AudioFormat getAudioFormat()
	{
    		float sampleRate = 8000.0F;
//8000,11025,16000,22050,44100
    		int sampleSizeInBits = 16;
//8,16
    		int channels = 1;
//1,2
    		boolean signed = true;
//true,false
    		boolean bigEndian = false;
//true,false
    		return new AudioFormat(sampleRate, sampleSizeInBits, channels, signed, bigEndian);
  	}
//=============================================//
  	private void playAudio() 
	{
System.out.println( "Before start in playAudio" );
    		try{
			socket = new Socket( ip.trim(), 4080 );
			is = socket.getInputStream();
System.out.println( "After start in playAudio" );
      			AudioFormat audioFormat = getAudioFormat();
      			audioInputStream = new AudioInputStream( is, audioFormat, AudioSystem.NOT_SPECIFIED  );
      			DataLine.Info dataLineInfo =  new DataLine.Info( SourceDataLine.class, audioFormat);
      			sourceDataLine = (SourceDataLine) AudioSystem.getLine(dataLineInfo);
      			sourceDataLine.open(audioFormat);
      			sourceDataLine.start();

      			Thread playThread = new PlayThread();
      			playThread.start();
    		} catch (Exception e) { 	System.out.println( "de poda poda  : " + e);	System.exit(0);	}//end catch
  	}//end playAudio
//=============================================//
	class PlayThread extends Thread
	{
  		byte tempBuffer[] = new byte[10000];

  		public void run()
		{
System.out.println( "AA1" );
    			try{
      				int cnt;
System.out.println( "AA2" );
      				while( ( ! socket.isClosed() ) &&  (cnt = audioInputStream.read( tempBuffer, 0, tempBuffer.length)) != -1)
				{
System.out.println( "AA3" );
				        	if(cnt > 0)
					{
          						sourceDataLine.write(tempBuffer,0,cnt);
        					}//end if
      				}//end while
System.out.println( "AA4" );
      				sourceDataLine.drain();
      				sourceDataLine.close();
    			}catch (Exception e) {	System.out.println(   "I here  : " + e);		}//end catch
			//System.exit(  0 );
  		}//end run
	}//end inner class PlayThread
//=============================================//
}