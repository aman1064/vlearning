package virtdesk;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;

public class Client extends Frame implements  ActionListener, Runnable
{
	TextArea output, input;
	Button start, send;

	Socket sock;
	OutputStream os;
	BufferedReader buf;
	String user_name = "";
//---------------------------------------------------------------------------------------------------   
	Client( String user)
	{
		super("ClientApp");	setLayout(null);	setBackground(Color.yellow);	user_name = user.trim();

		addWindowListener(new WindowAdapter()
		{	public void windowClosing(WindowEvent e)
			{ 	
				try{
					os = null;
					sock.close();
					sock = null;
				}catch( Exception ee ){	}
				dispose();
				System.runFinalization();
				System.gc();
			}	
		}	);

		Label l1 = new Label("Inbox");	l1.setBounds(80,30,100,20);

		Label l2 = new Label("Outbox");	l2.setBounds(290,30,100,20);

		input = new TextArea();		input.setBounds(10,50,200,200);	input.setEditable(false);

		output = new TextArea();		output.setBounds(220,50,200,200);

		start = new Button("Connect");	start.setBounds(75,270,70,20);		start.addActionListener( this);

		send = new Button("Send");	send.setBounds(270,270,70,20);	send.addActionListener( this);	send.setEnabled( false );

		add(l1);		add(l2);
		add(input);	add(output);
		add(start);	add(send);

		setSize(430, 300);	setResizable( false );	setVisible(true);
	}
//---------------------------------------------------------------------------------------------------
	public void actionPerformed(ActionEvent ae)
	{
		if( ae.getActionCommand().equals("Connect") )
		{
			connect();
			try{	Thread.sleep( 3000 );	}catch( Exception e ){}
			new Thread( this ).start();
			start.setEnabled( false );
			send.setEnabled( true );
		}
		else if( ae.getActionCommand().equals("Send") )
		{
			if( output.getText().trim().equals( "" ) && sock != null && ! sock.isClosed() )
			{
			}
			else
			{
				try{
					os.write( ( user_name + " : " + output.getText().trim() + "\n" ).getBytes() );
					os.flush();
				}catch( Exception e ){	}
				output.setText( "" );
			}
		}
	}
//--------------------------------------------------------------------------------------------------
	public void run() 
	{
		try{
			while( true )
			{
				input.append( buf.readLine().trim()  + "\n" );
			}
		} catch(Exception e)	{ System.err.println( "Data_Receiver_Thread:" + e);	}
	}
//------------------------------------------------------------------

	public static void  main(String args[])
	{
		try{	new Client( "localhost" );	}catch(Exception e)
		{	System.out.println(e);		}
	}

//------------------------------------------------------------------
	public void connect()
	{
		try{
			sock = new Socket( "localhost", 5090 );
			os = sock.getOutputStream();
			buf  = new BufferedReader( new InputStreamReader( sock.getInputStream() ) );
		}catch( Exception e ){	System.out.println( "Exception in Service_Thread of Server " + e );	}
	}
}