package virtdesk;

import java.awt.event.*;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Frame;
import java.awt.Robot;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

import java.net.*;
import java.io.*;

public class ScreenConsumer extends Frame
{
	Screen_content canvas;
	BufferedImage img;
	Image screen;
	Graphics graph;
	Color col;

	String ip_addr = "";
	public ScreenConsumer( String ip )
	{
		canvas = new Screen_content();
		add( canvas );
		ip_addr = ip;

		Thread t = new Thread()
		{
			public void run()
			{
				while( true )
				{
			   		try{
						Socket s = new Socket( ip_addr, 5040 );
						InputStream is = s.getInputStream();

						img = ImageIO.read( is );
						canvas.repaint();
						System.gc();
						Thread.sleep( 1000 );
					}catch( Exception e ){ System.out.println( "Inner  : " + e );	}
				}
			}
		};
		t.start();

		addWindowListener( new WindowAdapter()
		{
			public void windowClosing( WindowEvent we )
			{	System.gc();	System.exit( 0 );	}
		}	);
	}
	public static void main( String a[] )
	{
		ScreenConsumer sc = new ScreenConsumer( a[ 0 ] );
		java.awt.Dimension d = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
		sc.setSize(d.width-200, d.height-200 );
		sc.setVisible( true );
	}
	class Screen_content extends Canvas
	{
		public void paint( Graphics g)
		{
			try{
				if( img != null )
				{
					screen = createImage( getSize().width, getSize().height );
					graph = screen.getGraphics();
					col = new Color( 255, 255, 255 );
					graph.setColor( col );
					graph.fillRect( 0,0, getSize().width, getSize().height );
					graph.drawImage( (Image) img, 0,0, this );

					g.drawImage( screen, 0,0, this );
				}
			}catch( Exception e){	System.out.println( "In paint : " + e );	}
		}
		public void update( Graphics g ){	paint( g );	}
	}
}