package virtdesk;

import java.awt.*;
import java.awt.event.*;

public class MessageDialog extends Dialog
{
	public MessageDialog( Frame f, String msg )
	{
		super( f, "Message" );	setForeground( Color.green ); 	setBackground( Color.black );		setLayout( new FlowLayout() );

		Label l = new Label( msg.trim(), Label.CENTER );
		add( l );

		Button b = new Button( "Ok" );
		add( b );
		b.addActionListener( new ActionListener()
		{
			public void actionPerformed( ActionEvent ae )
			{
				setVisible( false );
				dispose();
				System.gc();
			} 
		});

		addWindowListener( new WindowAdapter()
		{
			public void windowClosing( WindowEvent we )
			{
				dispose();
			}
		} );

		pack();
		show();
	}
}