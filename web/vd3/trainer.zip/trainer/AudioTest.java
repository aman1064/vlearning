package virtdesk;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.sound.sampled.*;
import java.net.*;

public class AudioTest
{
  	AudioFormat audioFormat;
  	TargetDataLine targetDataLine;
	boolean stopClientListener = false;

	ServerSocket ss;
	Socket sockets[] = new Socket[ 5 ];
//=============================================//
  	public static void main( String args[]){	    new AudioTest();	  }
//=============================================//
  	public AudioTest()
	{
		try{
			for( int i = 0; i < sockets.length; i++ )
				sockets[ i ] = null;
		}catch( Exception e ){	System.out.println( "exception in AudioTest() : " + e );	};
	}
//=============================================//
	public void startAudioProduction()
	{
		try{	Thread.sleep( 1000 );	}catch( Exception e ){}
		new listenForClients();
	}
//=============================================//
	public void stopAudioTransmission()
	{
		stopClientListener = true;
		targetDataLine.stop();
		targetDataLine.close();
		try{
			Thread.sleep( 1000 );
			if( ss != null )
			{
				for( int i = 0; i < sockets.length; i++ )
				{
					if( sockets[ i ]  != null )
						sockets[ i ].close();
					sockets[ i ] = null;
				}

				ss.close();
				ss = null;
				System.gc();
System.out.println( "Audio Producer completed task" );
			}
		}catch( Exception e ){	System.out.println( "stopAudioTransmssion : " + e );	}
	}
//=============================================//
  	private AudioFormat getAudioFormat()
	{
    		float sampleRate = 8000.0F;
//8000,11025,16000,22050,44100
    		int sampleSizeInBits = 16;
//8,16
    		int channels = 1;
//1,2
    		boolean signed = true;
//true,false
    		boolean bigEndian = false;
//true,false
    		return new AudioFormat(sampleRate, sampleSizeInBits, channels, signed, bigEndian);
  	}
//=============================================//
  	private void captureAudio()
	{
    		try{
      			audioFormat = getAudioFormat();
      			DataLine.Info dataLineInfo = new DataLine.Info( TargetDataLine.class, audioFormat);
      			targetDataLine = (TargetDataLine) AudioSystem.getLine(dataLineInfo);
    		}catch (Exception e) {     e.printStackTrace();	   System.exit(0);	    }
  	}
//=============================================//
	public class listenForClients
	{
		public listenForClients()
		{
			try{
				captureAudio();
				new CaptureThread().start();

				ss = new ServerSocket( 4080 );

				Socket s;
				while( ! stopClientListener )
				{
					Thread.sleep( 1000 );
System.out.println( "listening" );
					s = null;
					s = ss.accept();
			innerlabel:	for( int i = 0; i < sockets.length; i++ )
					{
System.out.println( "assigning" );
						if( sockets[ i ] == null )
						{
							sockets[ i ] = s;
							break innerlabel;
						}
					}
				}
			}catch( Exception e){	System.out.println( "Exception in AudioTest.ListenForClient : " + e );	}
		}
	}
	class CaptureThread extends Thread
	{
  		public void run()
		{
    			AudioFileFormat.Type fileType = AudioFileFormat.Type.WAVE;
			try{
      				targetDataLine.open(audioFormat);
      				targetDataLine.start();
				AudioInputStream audioInputStream = new AudioInputStream(targetDataLine);

				byte data[] = new byte[ 10000 ];

				OutputStream os;
				int ch;
      				while(( ch = audioInputStream.read( data, 0, data.length)) != -1)
				{
					for( int i = 0; i < sockets.length; i++ )
					{
System.out.println( "5...."  + i );
						if( sockets[ i ] != null )
						{
						    try{
System.out.println( "6" );
							os = sockets[ i ].getOutputStream();

							os.write( data );
							os.flush();
						    }catch( Exception ee ){	sockets[ i ] = null;	}
System.out.println( "7" );
						}
					}

					if( stopClientListener )
						break;


					data = new byte[ 10000 ];
					System.gc();
				}
    			}catch (Exception e){	System.out.println( "Kya be gadhe : " );	e.printStackTrace()	;	}
  		}
	}
//=============================================//
}