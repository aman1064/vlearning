package virtdesk;

import java.awt.Robot;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

import java.net.*;
import java.io.*;

class Screen_Producer extends Thread
{
	static ServerSocket ss;
	static Socket s;
	static OutputStream os;

	boolean stop_screen_production = true;
	public Screen_Producer()
	{
		start();
	}

	public void stopThread()
	{
		stop_screen_production = true;

		try{
			Thread.sleep( 2000 );

			if( ss != null )
			{
			    try{
				ss.close();
				ss = null;
				System.gc();
			     }catch( Exception e ){	System.out.println( "serversocket terminator" );	}
			}
		}catch( Exception ede ){	System.out.println( "ScreenProducer : " +  ede );	}
	}

  	public void run()
        	{
		try{
			ss = new ServerSocket( 5040 );
System.out.println( "Server started" );
		}catch( Exception e){	System.out.println( "Error occured while start server : " + e );	}

System.out.println( "Starting desktop sharing" );
		stop_screen_production = false;
		while( ! stop_screen_production )
		{
		   try{
			s = ss.accept();
			os = s.getOutputStream();

			BufferedImage screencapture = new Robot().createScreenCapture(  new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()) );

     			ImageIO.write(screencapture, "jpg", os );

			os.flush();
			os.close();
			s.close();
		    }catch( Exception e ){	}
		}

		if( ss != null )
		{
		    try{
			ss.close();
			ss = null;
			System.gc();
		     }catch( Exception e ){	System.out.println( "serversocket terminator" );	}
		}
System.out.println( "Screen_Producer terminated" );
  	}
}