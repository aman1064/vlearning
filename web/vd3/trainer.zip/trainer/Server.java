package virtdesk;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;

public class Server extends Frame implements  ActionListener
{
	TextArea output, input;
	Button start, send;

	ServerSocket ss;
	Socket sockets [] = new Socket[ 5 ];
	String student_names [] = new String[ 5 ];

	OutputStream os;
//---------------------------------------------------------------------------------------------------   
	Server()
	{
		super("ServerApp");	setLayout(null);	setBackground(Color.yellow);

		addWindowListener(new WindowAdapter()
		{	public void windowClosing(WindowEvent e)
			{ 
				try{
					ss.close();
					ss = null;
				}catch( Exception ee){	}
				try{
					for( int i = 0 ;  i < sockets.length; i ++ ){		sockets[ i ] = null;		}
				}catch( Exception ee){	}
				dispose();	
				System.runFinalization();	
				System.gc();	
			}	
		}	);

		for( int i = 0 ;  i < sockets.length; i ++ ){		sockets[ i ] = null;		}
		for( int i = 0 ;  i < student_names.length; i ++ ){		student_names[ i ] = null;		}

		Label l1 = new Label("Inbox");	l1.setBounds(80,30,100,20);

		Label l2 = new Label("Outbox");	l2.setBounds(290,30,100,20);

		input = new TextArea();		input.setBounds(10,50,200,200);	input.setEditable(false);

		output = new TextArea();		output.setBounds(220,50,200,200);

		start = new Button("Start Server");	start.setBounds(75,270,70,20);		start.addActionListener( this);

		send = new Button("Send");	send.setBounds(270,270,70,20);	send.addActionListener( this);

		add(l1);		add(l2);
		add(input);	add(output);
		add(start);	add(send);

		setSize(430, 300);	setResizable( false );	setVisible(true);
	}
//---------------------------------------------------------------------------------------------------
	public void actionPerformed(ActionEvent ae)
	{
		if( ae.getActionCommand().equals("Start Server") )
		{
			new Service_Thread().start();
			start.setEnabled( false );
			send.setEnabled( true );
		}
		else if( ae.getActionCommand().equals("Send") )
		{
System.out.println( "sending" );
			if( output.getText().trim().equals( "" ) )
			{
			}
			else
			{
				for( int i = 0 ;  i < sockets.length; i ++ )
				{	
					if( sockets[ i ] == null || sockets[ i ].isClosed() ) 
					{
						sockets[ i ] = null;
					}					
					else if( sockets[ i ] != null )
					{
						try{
							os = sockets[ i ].getOutputStream();
							os.write( ( "Trainer : " + output.getText().trim() + "\n" ).getBytes() );
							os.flush();
						}catch( Exception e ){	sockets[ i ] = null;	}
System.out.println( "sent" );
					}
				}
				output.setText( "" );
			}
		}
	}
//--------------------------------------------------------------------------------------------------
	class Data_Receiver_Thread extends Thread
	{
		Socket sock;
		Data_Receiver_Thread( Socket s )
		{
			sock = s;
			start();
System.out.println( "Data reception started" );
		}
		public void run() 
		{
			try{
				InputStream is = sock.getInputStream();
				while( true )
				{
					Thread.sleep( 2000 );
					BufferedReader buf  = new BufferedReader( new InputStreamReader( is ) );
					input.append( buf.readLine().trim() + "\n"  );
System.out.println( "Data Received" );
				}
			} catch(Exception e)	{ System.err.println( "Data_Receiver_Thread:" + e);	}
		}
	}
//------------------------------------------------------------------

	public static void  main(String args[])
	{
		try{	new Server();	}catch(Exception e)
		{	System.out.println(e);		}
	}

//------------------------------------------------------------------
	class Service_Thread extends Thread
	{
		public void run()
		{
			try{
				ss = new ServerSocket( 5090 );
				Socket tmp_sock;
				while( true )
				{
					Thread.sleep( 2000 );
					tmp_sock = null;
					tmp_sock = ss.accept();

					for( int i = 0 ;  i < sockets.length; i ++ )
					{	
						if( sockets[ i ] == null )
						{
							sockets[ i ] = tmp_sock;
							new Data_Receiver_Thread( tmp_sock );
							break;
						}
					}
				}
			}catch( Exception e ){	System.out.println( "Exception in Service_Thread of Server " + e );	}
		}
	}
}