package virtdesk;

import java.awt.*;
import java.awt.event.*;

public class CustomLabel extends Label
{
	Image img;
	int x = 0, y = 0;
	CustomLabel( Image img, int x, int y )
	{
		this.img = img;
		this.x = x;
		this.y = y;
	}
	public void paint( Graphics g )
	{
		g.drawImage( img, x, y, this );
	}
}