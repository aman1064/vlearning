package virtdesk;

import java.awt.*;
import java.awt.event.*;

public class ProgressCanvas extends Canvas
{
	int x = 10;
	Image img;
	Graphics img_graph;
	public ProgressCanvas( )
	{
		setSize( 200, 90 );
		Thread t = new Thread()
		{
			public void run()
			{
				while( true )
				{
					x += 1;
					if( ( x +10 ) > 170 )
						x = 10;
					System.gc();
					try{	Thread.sleep( 100 );	}catch( Exception e ){}
					repaint();
				}
			}
		};
		t.start();
	}
	public void paint( Graphics g )
	{
		img = createImage( 200, 90 );
		img_graph = img.getGraphics();

		img_graph.setColor( Color.white );
		img_graph.fillRect( 0, 0, 200, 90 );
		img_graph.setColor( Color.black );
		img_graph.drawRect( 10, 20, 170, 20 );
		img_graph.setColor( Color.green );
		img_graph.fillRect( x, 21, 20, 19 );

		g.drawImage( img, 0, 0, this );

	}
	public void update( Graphics g){	paint( g );	}
}