package virtdesk;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;

public class CustomDialog extends Dialog implements ActionListener
{
	TextField tf;
	Button ok_btn, cancel_btn, reset_btn;
	WaitDialog wd;

	Frame f;
	String txtfld_str = "";
	String user_name = "";

	Screen_Producer producer;
	AudioTest AudioProducer;

	boolean class_started_success_flag = false;
	String tmp_batch_id = "";

	public CustomDialog( Frame f, String name )
	{
		super( f, "Start Virtual Class Room", true );	setLayout( null );
		this.f = f;	this.user_name = name.trim();
		
		Label l = new Label( "Enter Batch Id whose class is to be started", Label.CENTER ); 	l.setBounds( 1, 20, 320, 24 );

		tf = new TextField( txtfld_str );	tf.setBounds( 10, 85, 170, 25 );	add( l );	add( tf );

		ok_btn = new Button( "O K" );
		ok_btn.setBounds( 200, 60, 100, 20 );
		ok_btn.addActionListener( this );

		reset_btn = new Button( "R E S E T" );
		reset_btn.setBounds( 200, 85, 100, 20 );
		reset_btn.addActionListener( this );

		cancel_btn = new Button( "C A N C E L" );
		cancel_btn.setBounds( 200, 110, 100, 20 );
		cancel_btn.addActionListener( this );

		add( ok_btn );	add( reset_btn );	add( cancel_btn );

		setResizable( false );	setSize( 321, 172 );	show();
	}
	public void actionPerformed( ActionEvent ae )
	{
		if( ae.getSource() == ok_btn )
		{
			dispose();
			String batch_id = tf.getText();

			if( batch_id == null || batch_id.trim().equals( "" ) )
			{
				new MessageDialog( f, "Operation failed.  Inputs are not complete. Please specify the batch id"  );
			}
			else
			{
				wd = new WaitDialog( f );

				try{
					InetAddress ip = InetAddress.getByName( "localhost" );

					URL url =  new URL( "http://localhost:8080/vd3/class_starter.jsp?trainer_id=" + user_name + "&batch_id=" + batch_id.trim() + "&ip=" + ip.getHostAddress() );
					URLConnection urlcon = url.openConnection();
					InputStream is = urlcon.getInputStream();

					int ch;
					String str = "";
					while( (ch = is.read() ) != -1 )
						str += (char) ch;

					is.close();
					is = null;
					System.gc();

					wd.dispose();
					wd = null;
					System.gc();

					if( str.trim().equals( "success" ) )
					{
						new MessageDialog( f, "Virtual classroom has been started successfully." );

						producer = new Screen_Producer();

						class_started_success_flag = true;
						tmp_batch_id = batch_id.trim();
					}
					else if( str.trim().equals( "failure" ) )
						new MessageDialog( f, "Classroom startup failed.   The batch id specified is wrong!!" );
					else if( str.trim().equals( "failure2" ) )
						new MessageDialog( f, "Classroom startup failed.  You do not have privileges to start class for this batch!!" );
					else if( str.trim().equals( "failure3" ) )
						new MessageDialog( f, "Your request failed.  This class is already in progress.  You cannot start it now!!" );
				}catch( Exception e )
				{
					new MessageDialog( f, "Classroom startup failed.   Server is currently not available" );
				}
			}
		}
		else if( ae.getSource() == cancel_btn )
		{
			tf = null;
			ok_btn = null; cancel_btn = null; reset_btn = null;
			f = null;

			System.runFinalization();
			System.gc();
			dispose();
		}
		else if( ae.getSource() == reset_btn )
		{
			tf.setText( txtfld_str );
		}
	}
	public boolean is_class_started_success_flag()
	{
		return class_started_success_flag;
	}
	public Screen_Producer giveScreen_Producer()
	{
		return producer;
	}
	public AudioTest giveAudio_Producer()
	{
		return AudioProducer;
	}
	public String giveBatchID()
	{
		return tmp_batch_id;
	}
}