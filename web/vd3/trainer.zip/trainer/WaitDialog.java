package virtdesk;

import java.awt.*;
import java.awt.event.*;

public class WaitDialog extends Dialog
{
	public WaitDialog( Frame f)
	{
		super( f, "Please wait" );	setBackground( Color.white ); 	
		setSize( 200, 100 );

		add( new CustomLabel( Toolkit.getDefaultToolkit().createImage( "imgs/wait.gif" ), 0, 0 ), BorderLayout.NORTH );

		add( new ProgressCanvas() );
		setResizable( false );
		show();

		addWindowListener( new WindowAdapter()
		{
			public void windowClosing( WindowEvent we )
			{	dispose();	}
		} );
	}
	public WaitDialog( Frame f, String msg )
	{
		super( f, "Error/Alert Message!!" );	setBackground( Color.white );
		setSize( msg.length()  * 6, 100 );

		add( new Label( msg.trim() ));
		show();

		addWindowListener( new WindowAdapter()
		{
			public void windowClosing( WindowEvent we )
			{	dispose();	}
		} );
	}
}
